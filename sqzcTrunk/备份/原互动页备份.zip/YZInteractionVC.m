//
//  YZInteractionVC.m
//  SMARTCHANGPING
//
//  Created by 韩云智 on 2017/1/11.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "YZInteractionVC.h"

#import "YZDynamicModel.h"

#import "YZThingsTextCollectionCell.h"
#import "YZToolCollectionReusableView.h"

@interface YZInteractionVC ()<UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView * myCollectionView;
@property (nonatomic, strong) NSMutableArray * listDatas;
@property (nonatomic, strong) NSMutableArray * hotLineDatas;

@end

@implementation YZInteractionVC

#pragma mark --- 数据请求

- (void)getInteractionData{
    WeakSelf;
    [YZNetMaster post:SERVER_INTERACTION_LIST parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
        [weakSelf.myCollectionView.mj_header endRefreshing];
        if ([responseObject[@"status"] integerValue] == 1) {
            NSArray * hotlines = responseObject[@"data"][@"hotline"];
            if ([hotlines isKindOfClass:[NSArray class]]) {
                [weakSelf.hotLineDatas removeAllObjects];
                for (NSDictionary * dic in hotlines) {
                    [weakSelf.hotLineDatas addObject:[YZDynamicModel modelWithDic:dic]];
                }
            }
            NSArray * collects = responseObject[@"data"][@"collect"];
            if ([collects isKindOfClass:[NSArray class]]) {
                [weakSelf.listDatas removeAllObjects];
                for (NSDictionary * dic in collects) {
                    [weakSelf.listDatas addObject:[YZDynamicModel modelWithDic:dic]];
                }
                [weakSelf.myCollectionView reloadData];
            }
        }
        
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        [weakSelf.myCollectionView.mj_header endRefreshing];
    }];
}

#pragma mark --- 懒加载
- (NSMutableArray *)listDatas{
    if (!_listDatas) {
        _listDatas = [NSMutableArray new];
    }
    return _listDatas;
}

- (NSMutableArray *)hotLineDatas{
    if (!_hotLineDatas) {
        _hotLineDatas = [NSMutableArray new];
        [self getInteractionData];
    }
    return _hotLineDatas;
}

#pragma mark --- 生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self changeBackBarButton];
    [self upView];
}

- (void)upView{
    
    YZCollectionViewFlowLayout * flowLayout = [YZCollectionViewFlowLayout new];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    flowLayout.sectionInset = UIEdgeInsetsZero;
    flowLayout.minimumLineSpacing = 0;
    flowLayout.minimumInteritemSpacing = 0;
    
    flowLayout.headerReferenceSize = CGSizeMake(MY_WIDTH, 76*WIDTH_RATIO/2);
    
    _myCollectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    _myCollectionView.backgroundColor = [UIColor clearColor];
    
    _myCollectionView.delegate = self;
    _myCollectionView.dataSource = self;
    
    [_myCollectionView registerClass:[YZThingsTextCollectionCell class] forCellWithReuseIdentifier:@"listCell"];
    [_myCollectionView registerClass:[YZToolCollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];
    
    [self.view sd_addSubviews:@[_myCollectionView]];
    _myCollectionView.sd_layout
    .topEqualToView(self.view)
    .leftEqualToView(self.view)
    .rightSpaceToView(self.view, -0.1*WIDTH_RATIO)
    .bottomEqualToView(self.view);
    
    WeakSelf;
    _myCollectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf getInteractionData];
    }];
    
    
//    _myTableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
//    _myTableView.backgroundColor = [UIColor clearColor];
//    _myTableView.rowHeight = 80*WIDTH_RATIO/2;
//    _myTableView.bounces = NO;
//    _myTableView.separatorStyle = UITableViewCellAccessoryNone;
//    _myTableView.tableHeaderView = [self upHeaderView];
//    _myTableView.delegate = self;
//    _myTableView.dataSource = self;
//    
//    [self.view sd_addSubviews:@[_myTableView]];
//    _myTableView.sd_layout
//    .topEqualToView(self.view)
//    .leftEqualToView(self.view)
//    .rightEqualToView(self.view)
//    .bottomEqualToView(self.view);
//    
//    WeakSelf;
//    _myTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//        [weakSelf getInteractionData];
//    }];
}

- (UIView *)upHeaderView{
    UIView * headerView = [UIView new];
    headerView.frame = CGRectMake(0, 0, MY_WIDTH, 332*WIDTH_RATIO/2);
    
    UIView * textView = [UIView new];
    textView.backgroundColor = [UIColor whiteColor];
    
    UILabel * label1 = [self titleLabelWithText:@"热线电话"];
    UILabel * label2 = [self titleLabelWithText:@"征集调查"];
    
    [headerView sd_addSubviews:@[textView, label1, label2]];
    
    textView.sd_layout
    .topSpaceToView(headerView, 76*WIDTH_RATIO/2)
    .bottomSpaceToView(headerView, 76*WIDTH_RATIO/2)
    .leftEqualToView(headerView)
    .rightEqualToView(headerView);
    
    label1.sd_layout
    .topEqualToView(headerView)
    .bottomSpaceToView(textView, 0)
    .leftSpaceToView(headerView, 32*WIDTH_RATIO/2)
    .rightSpaceToView(headerView, 32*WIDTH_RATIO/2);
    
    label2.sd_layout
    .topSpaceToView(textView, 0)
    .bottomEqualToView(headerView)
    .leftSpaceToView(headerView, 32*WIDTH_RATIO/2)
    .rightSpaceToView(headerView, 32*WIDTH_RATIO/2);
    
    UILabel * subLabel1 = [self subLabelWithText:@"值班电话" tag:0];
    UILabel * subLabel2 = [self subLabelWithText:@"信访电话" tag:1];
    UILabel * subLabel3 = [self subLabelWithText:@"热线服务电话" tag:2];
    UILabel * subLabel4 = [self subLabelWithText:@"举报电话" tag:3];
    
    [textView sd_addSubviews:@[subLabel1, subLabel2, subLabel3, subLabel4]];
    
    subLabel1.sd_layout
    .topSpaceToView(textView, 20*WIDTH_RATIO/2)
    .leftSpaceToView(textView, 40*WIDTH_RATIO/2)
    .widthIs(headerView.width/2 - 50*WIDTH_RATIO/2)
    .heightIs(70*WIDTH_RATIO/2);
    
    subLabel2.sd_layout
    .topEqualToView(subLabel1)
    .leftSpaceToView(subLabel1, 20*WIDTH_RATIO/2)
    .heightRatioToView(subLabel1, 1)
    .rightSpaceToView(textView, 40*WIDTH_RATIO/2);
    
    subLabel3.sd_layout
    .topSpaceToView(subLabel1, 0)
    .leftEqualToView(subLabel1)
    .rightEqualToView(subLabel1)
    .bottomSpaceToView(textView, 20*WIDTH_RATIO/2);
    
    subLabel4.sd_layout
    .topEqualToView(subLabel3)
    .bottomEqualToView(subLabel3)
    .leftEqualToView(subLabel2)
    .rightEqualToView(subLabel2);
    
    
    return headerView;
}

- (UILabel *)titleLabelWithText:(NSString *)text{
    UILabel * label = [UILabel new];
    label.font = [UIFont boldSystemFontOfSize:28*WIDTH_RATIO/2];
    label.textColor = YZ_COLOR(0x333333);
    label.text = text;
    return label;
}

- (UILabel *)subLabelWithText:(NSString *)text tag:(NSInteger)tag{
    UILabel * label = [UILabel new];
    label.tag = tag+100;
    label.font = [UIFont systemFontOfSize:22*WIDTH_RATIO/2];
    label.textColor = YZ_COLOR(0x333333);
    label.text = text;
    return label;
}

#pragma mark --- collection

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (section == 0) {
        return self.hotLineDatas.count;
    }else{
        return self.listDatas.count;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return CGSizeMake(MY_WIDTH/2, 80*WIDTH_RATIO/2);
    }else{
        return CGSizeMake(MY_WIDTH, 80*WIDTH_RATIO/2);
    }
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    YZThingsTextCollectionCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"listCell" forIndexPath:indexPath];

    
    
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionReusableView * view;
    
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        YZToolCollectionReusableView * header = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"header" forIndexPath:indexPath];
        
        if (indexPath.section == 0) {
            header.myTitleLabel.text = @"热线电话";
        }else{
            header.myTitleLabel.text = @"征集调查";
        }
        
        view = header;
    }
    
    return view;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    self.view.userInteractionEnabled = NO;
    YZWabVC * webVC = [YZWabVC new];
//    webVC.title = _datas[indexPath.section][indexPath.item];
    
    [[YZRootVC sharedManager].navigationController pushViewController:webVC animated:YES];
}


#pragma mark --- table
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.listDatas.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:26*WIDTH_RATIO/2];
        cell.textLabel.textColor = YZ_COLOR(0x333333);
        
        cell.imageView.image = [UIImage imageNamed:CELL_POINT_IMG];
    }
    
    cell.textLabel.text =  [_listDatas[indexPath.row] title];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.view.userInteractionEnabled = NO;
    YZDynamicModel * model = _listDatas[indexPath.row];
    YZWabVC * webVC = [YZWabVC new];
    [webVC loadUrl:[NSString stringWithFormat:@"%@%@?id=%@", YZ_SERVER, SERVER_NEWS_DETAILS, model.id]];
    webVC.hasShare = YES;
    webVC.title = @"详情";
    [self.navigationController pushViewController:webVC animated:YES];
}

@end
