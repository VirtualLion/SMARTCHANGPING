//
//  YZInteractionVC.h
//  SMARTCHANGPING
//
//  Created by 韩云智 on 2017/1/11.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "YZBaseVC.h"

@interface YZInteractionVC : YZBaseVC

@end
